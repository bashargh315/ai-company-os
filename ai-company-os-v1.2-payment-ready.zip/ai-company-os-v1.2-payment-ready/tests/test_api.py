import os, tempfile
from fastapi.testclient import TestClient

fd, path = tempfile.mkstemp(suffix='.db'); os.close(fd)
os.environ['AIOS_DB_PATH'] = path
from backend.app import app
client = TestClient(app)

def test_health():
    r=client.get('/api/health'); assert r.status_code==200; assert r.json()['version']=='1.2.0'

def test_first_client_and_dedupe():
    h={'X-Demo-User':'demo-client'}
    r=client.post('/api/pilot/start',json={'company_name':'اختبار v1','description':'متجر موبايلات في سوريا','goal':'زيادة المبيعات'},headers=h)
    assert r.status_code==200
    cid=r.json()['company_id']
    r1=client.post('/api/execution/launch',json={'company_id':cid,'request':'زيادة المبيعات','audience':'عملاء جدد'},headers=h)
    assert r1.status_code==200 and r1.json()['deduplicated'] is False
    r2=client.post('/api/execution/launch',json={'company_id':cid,'request':'زيادة المبيعات','audience':'عملاء جدد'},headers=h)
    assert r2.status_code==200 and r2.json()['deduplicated'] is True
    r3=client.get(f'/api/companies/{cid}/latest-result',headers=h)
    assert r3.status_code==200 and r3.json()['result'] is not None
